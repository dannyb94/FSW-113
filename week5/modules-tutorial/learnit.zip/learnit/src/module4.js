console.log("Load Module 4 .... Start")

let courseName ="FSW113"
let liveSession = "02/02/2020"

export let Course = courseName
export let Session =  liveSession

console.log("Load Module 4 ..... End")