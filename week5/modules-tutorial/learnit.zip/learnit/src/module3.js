//CLO3
let courseName ="FSW113"
let liveSession = "02/02/2020"

export let Course = courseName
export let Session =  liveSession