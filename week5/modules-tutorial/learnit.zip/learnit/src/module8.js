let courseName = "FSW113"
let liveSession = "02/02/2020"

export {courseName as default, liveSession}