let courseName = "FSW113"
let liveSession = "02/02/2020"

let combine = function(){
    return `CourseName = ${courseName} in ${liveSession}`
}
export {courseName, liveSession, combine}